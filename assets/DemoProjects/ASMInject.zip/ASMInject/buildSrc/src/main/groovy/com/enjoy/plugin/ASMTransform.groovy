package com.enjoy.plugin

import com.android.build.api.transform.Format;
import com.android.build.api.transform.QualifiedContent;
import com.android.build.api.transform.Transform
import com.android.build.api.transform.TransformException
import com.android.build.api.transform.TransformInvocation
import com.android.build.api.transform.TransformOutputProvider;
import com.android.build.gradle.internal.pipeline.TransformManager
import com.android.utils.FileUtils
import com.google.common.collect.FluentIterable
import org.apache.commons.codec.digest.DigestUtils
import org.objectweb.asm.ClassReader
import org.objectweb.asm.ClassWriter;


class ASMTransform extends Transform {
// 1、任务的名称
    @Override
    String getName() {
        return "asm";
    }
// 2、可以是Class可以是resources这里只需要Class
    @Override
    Set<QualifiedContent.ContentType> getInputTypes() {
        return TransformManager.CONTENT_CLASS
    }
// 3、只对引入插件的模块生效
    @Override
    Set<? super QualifiedContent.Scope> getScopes() {
        return TransformManager.PROJECT_ONLY
    }

    @Override
    boolean isIncremental() {
        return false
    }

    @Override
    void transform(TransformInvocation transformInvocation) throws TransformException, InterruptedException, IOException {
        TransformOutputProvider outputProvider = transformInvocation.outputProvider
        //清理文件
        outputProvider.deleteAll()

        def inputs = transformInvocation.inputs
        inputs.each {
// 4、因为是transformManager.PROJECT_ONLY 只管当前的src目录，不管jar目录，不需要 it.jarInputs
            def directoryInputs = it.directoryInputs
            directoryInputs.each {
                String dirName = it.name
                File src = it.getFile();
                println("源目录：" + src)
// 5、transform是一个一个执行的，上一个transoform的输出是下一个的输入。
// 源目录：F:\5.Android\Projects\ASMInject\ASMInject\app\build\intermediates\javac\debug\compileDebugJavaWithJavac\classes
// 目标目录：F:\5.Android\Projects\ASMInject\ASMInject\app\build\intermediates\transforms\asm\debug\0
                String md5Name = DigestUtils.md5Hex(src.absolutePath)
                File dest = outputProvider.getContentLocation(dirName + md5Name, // 必须保证是唯一的
                        it.contentTypes, // 类型
                        it.scopes, // 作用域
                        Format.DIRECTORY);
//根据这些参数，outputProvider.getContentLocation 会返回一个 File 对象，表示这个内容的位置。如果格式是 Format.DIRECTORY ，那么结果是一个目录的文件位置；如果格式是 Format.JAR ，那么结果是一个表示要创建的 jar 包的文件。
                println("目标目录：" + dest)
                println("dirName：" + dirName) // dirName：e47eef71c08b0d42c571e631eb55645c006d92a2
                println("md5Name：" + md5Name) // md5Name：5f3e38731d3c990d7ad79d6404c3b796
                //插桩
                processInject(src, dest);
            }
        }
    }

    void processInject(File src, File dest) {
        String dir = src.absolutePath
        FluentIterable<File> allFiles = FileUtils.getAllFiles(src)
        for (File file : allFiles) {
            println("需要插桩的文件：" + file.name)
            FileInputStream fis = new FileInputStream(file)
            //插桩
            ClassReader cr = new ClassReader(fis)
            // 写出器
            ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES)
            //分析，处理结果写入cw
            cr.accept(new ClassInjectTimeVisitor(cw, file.name), ClassReader.EXPAND_FRAMES)

            byte[] newClassBytes = cw.toByteArray()
            //class文件绝对地址
            String absolutePath = file.absolutePath
            //class文件绝对地址去掉目录，得到全类名
            String fullClassPath = absolutePath.replace(dir, "")
            File outFile = new File(dest, fullClassPath)
            FileUtils.mkdirs(outFile.parentFile)
            FileOutputStream fos = new FileOutputStream(outFile)
            fos.write(newClassBytes)
            fos.close()
        }

    }
}
